@extends('layouts.master')

@section('page_title', "Documentation")

@section('content')
<div class="hero-ban overlay pb-6 mb-3" id="hero" >
    <div class="container">
        <div class="intro-group row h-auto pt-8 text-center">
            <!-- Texte Gauche -->
            <div class="intro col-lg-12 col-md-12 col-sm-12">
                <h1 class="text-black mb-4" data-aos="fade-up" data-aos-delay="100">
                    Notre documentation: le guide Kover
                </h1>
            </div>
        </div>
    </div>
</div>

<!-- En construction -->
<section class="building">

</section>
@endsection
